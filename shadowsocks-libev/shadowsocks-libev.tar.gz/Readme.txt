系统：CentOS 6+
将文件夹里的所有文件上传到服务器的同一个文件夹下：
安装：chmod +x shadowsocks-libev.sh &&  ./shadowsocks-libev.sh
卸载：cd /root && ./shadowsocks-libev.sh uninstall
启动：/etc/init.d/shadowsocks start
停止：/etc/init.d/shadowsocks stop
重启：/etc/init.d/shadowsocks restart
查看状态：/etc/init.d/shadowsocks status

更新：下载以下文件的新版本，放到文件夹里，删去旧版本的文件，注意不要改动文件名
libsodium.tar.gz #下载:https://github.com/jedisct1/libsodium/releases
mbedtls.tgz #下载:https://tls.mbed.org/download-archive（GPL）
shadowsocks_libev.tar.gz #下载:https://github.com/shadowsocks/shadowsocks-libev/tags
shadowsocks-libev #下载:https://github.com/teddysun/shadowsocks_install/blob/master/shadowsocks-libev